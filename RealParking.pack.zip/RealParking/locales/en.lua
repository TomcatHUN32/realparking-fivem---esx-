Locales['en'] = {
    -- 💰 Economy
    noMoney        = "You don't have enough money in your bank.",
    noCash         = "You don't have enough cash.",
    ticketBought   = "You bought a parking ticket for $%s.",
    ticketFailed   = "Failed to issue parking ticket.",
    needTicket     = "You need a parking ticket to park here.",
    ticketRemoveFailed = "Could not remove parking ticket from your inventory.",

    -- 🚗 Parking actions
    notInVehicle   = "You are not in a vehicle.",
    parkedOk       = "Vehicle parked successfully.",
    endOk          = "Parking ended successfully.",
    freedOk        = "Parking spot freed.",
    mustBeInVehicle = "You must be in your vehicle to end parking.",
    spotLocked     = "This parking spot is already taken.",
    spotOwned      = "This spot is reserved by ~b~%s~s~.",
    notYourSpot    = "This parking spot does not belong to you.",
    parkedTooFar   = "You are too far from the parking spot.",

    -- 🅿️ Prompts
    pressEToBuy    = "Press ~INPUT_CONTEXT~ to buy a Parking Ticket ($%s).",
    pressEPark     = "Press ~INPUT_CONTEXT~ to park your vehicle.",
    pressEUnpark   = "Press ~INPUT_CONTEXT~ to end parking.",

    -- 🧾 Impound system
    noImpound      = "You don't have any impounded vehicles.",
    redeemSuccess  = "You successfully retrieved your impounded vehicle.",
    impoundedInfo  = "This vehicle has been impounded.",
    impoundPay     = "You paid $%s to retrieve your vehicle.",
    impoundError   = "Error while processing impound retrieval.",

    -- ✳️ Impound NPC (interactions)
    impound_redeem_label  = "Retrieve Vehicle ($%d)",
    impound_help_text     = "~g~[E]~s~ Retrieve impounded vehicle ($%d)",
    impound_redeem_success = "✅ You have successfully retrieved your vehicle!",
    impound_deleted_log   = "Deleted from world (impounded): %s",

    -- 🛠️ System messages
    dbTableCreated   = "✅ Database table created with rotation support.",
    startCheck       = "Start check...",
    noImpoundNeeded  = "No vehicles waiting for impound.",
    impoundDone      = "Impounded (Not Parked): %s",
    summary          = "All: %d | Parked: %d | Impounded: %d",

    -- ⚠️ Errors / Warnings
    invalidVehicle   = "Invalid vehicle detected.",
    noVehicleFound   = "No owned vehicle found for this plate.",
    ticketItemMissing = "Parking ticket item not found in inventory.",
    alreadyParked    = "This vehicle is already parked.",
}
