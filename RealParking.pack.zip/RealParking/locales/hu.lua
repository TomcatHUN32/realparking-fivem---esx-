Locales['hu'] = {
    -- 💰 Gazdaság
    noMoney        = "Nincs elég pénzed a bankban.",
    noCash         = "Nincs nálad elég készpénz.",
    ticketBought   = "Sikeresen vásároltál parkolójegyet %s$ értékben.",
    ticketFailed   = "A parkolójegy kiállítása sikertelen volt.",
    needTicket     = "Ehhez a parkoláshoz parkolójegyre van szükséged.",
    ticketRemoveFailed = "Nem sikerült eltávolítani a parkolójegyet az inventorydból.",

    -- 🚗 Parkolási műveletek
    notInVehicle   = "Nem ülsz járműben.",
    parkedOk       = "A jármű sikeresen leparkolva.",
    endOk          = "A parkolás sikeresen befejezve.",
    freedOk        = "A parkolóhely felszabadítva.",
    mustBeInVehicle = "A járműben kell ülnöd a parkolás befejezéséhez.",
    spotLocked     = "Ez a parkolóhely már foglalt.",
    spotOwned      = "Ezt a helyet ~b~%s~s~ foglalta le.",
    notYourSpot    = "Ez nem a te parkolóhelyed!",
    parkedTooFar   = "Túl messze vagy a parkolóhelytől.",

    -- 🅿️ Interakciós üzenetek
    pressEToBuy    = "Nyomd meg az ~INPUT_CONTEXT~ gombot parkolójegy vásárlásához ($%s).",
    pressEPark     = "Nyomd meg az ~INPUT_CONTEXT~ gombot a parkoláshoz.",
    pressEUnpark   = "Nyomd meg az ~INPUT_CONTEXT~ gombot a parkolás befejezéséhez.",

    -- 🧾 Lefoglalás / Impound rendszer
    noImpound      = "Nincs lefoglalt járműved.",
    redeemSuccess  = "Sikeresen kiváltottad a lefoglalt járművedet.",
    impoundedInfo  = "Ez a jármű lefoglalásra került.",
    impoundPay     = "Fizettél %s$-t a jármű kiváltásáért.",
    impoundError   = "Hiba történt a jármű kiváltása közben.",

    -- 🧍 Lefoglalt NPC (interakciók)
    impound_redeem_label  = "Kiváltás ($%d)",
    impound_help_text     = "~g~[E]~s~ Lefoglalt jármű kiváltása ($%d)",
    impound_redeem_success = "✅ Sikeresen kiváltottad a járművet!",
    impound_deleted_log   = "Törölve világból (lefoglalt): %s",

    -- 🛠️ Rendszerüzenetek
    dbTableCreated = "✅ Adatbázis tábla létrehozva, rotáció támogatással.",
    startCheck     = "Ellenőrzés indítása...",
    noImpoundNeeded = "Nincs lefoglalásra váró jármű.",
    impoundDone    = "Lefoglalva (nem parkolt): %s",
    summary        = "Összes: %d | Parkolt: %d | Lefoglalt: %d",

    -- ⚠️ Hibák / Figyelmeztetések
    invalidVehicle = "Érvénytelen jármű.",
    noVehicleFound = "Nem található jármű a megadott rendszámhoz.",
    ticketItemMissing = "A parkolójegy tárgy nem található az inventorydban.",
    alreadyParked  = "Ez a jármű már parkolva van.",
}
