fx_version 'cerulean'
game 'gta5'

lua54 'yes'

author 'TomcatHUN32'
description 'A realistic parking and impound system for ESX-based FiveM servers.'
version '1.0.0'

------------------------------------------------------------
-- 🔒 Escrow settings
-- Only config + locale files remain editable
------------------------------------------------------------
escrow_ignore {
    'config.lua',
    'locales/*.lua',
    '@oxmysql/lib/MySQL.lua'
}

------------------------------------------------------------
-- 📦 Shared scripts (load order matters)
------------------------------------------------------------
shared_scripts {
    '@es_extended/imports.lua',
    'config.lua',
    'shared/lang.lua', -- encrypted (NOT ignored)
    'locales/en.lua',
    'locales/hu.lua'
}

------------------------------------------------------------
-- 🧠 Server scripts
------------------------------------------------------------
server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server/main.lua'
}

------------------------------------------------------------
-- 🎮 Client scripts
------------------------------------------------------------
client_scripts {
    'client/main.lua'
}

------------------------------------------------------------
-- ⚙️ Dependencies
------------------------------------------------------------
dependencies {
    'es_extended',
    'oxmysql',
    'ox_inventory'
}

dependency '/assetpacks'