Config = {}

------------------------------------------------------------
-- 🌍 Language & Locale
------------------------------------------------------------
-- Available locales: 'hu', 'en'
Config.Locale = 'en' -- Choose 'hu' or 'en'

------------------------------------------------------------
-- 💳 Payment & Ticket
------------------------------------------------------------
-- 'bank' = use bank account
-- 'cash' or 'money' = use wallet cash
Config.PaymentType = 'cash'
Config.TicketPrice = 500
Config.TicketItem  = 'parking_ticket'

------------------------------------------------------------
-- 🧍 NPC Seller (Parking Ticket Seller)
------------------------------------------------------------
Config.Seller = {
    enabled = true,
    model = 's_m_m_autoshop_02', -- ped model
    coords = vec3(215.261536, -809.670349, 30.728882), -- location
    heading = 70.0,
    scenario = 'WORLD_HUMAN_CLIPBOARD', -- idle animation
    blip = {
        enabled = true,
        sprite = 280,
        color = 2,
        scale = 0.8,
        name = 'Parking Ticket Seller'
    },
    useOxTarget = true -- true = use ox_target, false = use "E" key interaction
}

------------------------------------------------------------
-- 🚓 Impound (Impounded Vehicle NPC)
------------------------------------------------------------
Config.Impound = {
    model = "s_m_m_lathandy_01",
    coords = vec3(238.615387, -757.872498, 34.621216), -- NPC location
    heading = 225.0,
    fee = 100, 
    scenario = "WORLD_HUMAN_CLIPBOARD", -- NPC animation
    spawn = { x = 244.589020, y = -758.531860, z = 34.621216, h = 270.0 } -- spawn point for released vehicle
}

------------------------------------------------------------
-- 🅿️ Parking Spots
------------------------------------------------------------
-- These are the basic “square lot” parking spots used for testing.
-- Two sample spots are included below for demonstration.
-- You can freely add more using the same pattern shown here.
Config.Spots = {
    { name = 'RP_1', x = 220.219788, y = -809.116455, z = 30.661499, heading = 70.0 },
    { name = 'RP_2', x = 221.024170, y = -806.558228, z = 30.678345, heading = 70.0 },
}

------------------------------------------------------------
-- 🧾 Text placeholders (deprecated)
-- All in-game texts are handled by locales in /locales/
------------------------------------------------------------
Config.Text = {}

------------------------------------------------------------
-- 🧠 Debug options
------------------------------------------------------------
Config.Debug = true -- Set to false to disable console logs

------------------------------------------------------------
-- 🪓 Discord logging (logs all parking events)
------------------------------------------------------------
Config.Discord = {
    enabled  = true, -- false = disabled
    webhook  = "https://discordapp.com/api/webhooks/1433789718402961474/iRElHHXQZDoU36QeEJaboRQtbDbwEbGDcrHOzgTJnefOZ6py8sp8D_R2Sp-f51jccQZ3", 
    username = "RealParking Logs",
    avatar   = "https://i.imgur.com/xxxxxxxx.png", -- optional: Discord avatar
    color = {
        park    = 65280,    -- green: parked
        unpark  = 16776960, -- yellow: unparked
        impound = 16711680  -- red: impounded or blue: Impound Redeemed
    }
}
